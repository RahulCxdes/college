package com.example.demo.controller;


import java.util.Collections;
import java.util.Comparator;
import java.util.List;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Articles;
import com.example.demo.model.NewsResponse;

@RestController
public class Controller {

    @GetMapping("/newsapi/{country}/{category}")
    public NewsResponse getWord(@PathVariable("country") String country, @PathVariable("category") String category)
    {
        String apiKey = "df8baec46fe347c99c15e21b9ae9f9a3";
        String URL = "https://newsapi.org/v2/top-headlines?country=" + country + "&category=" + category + "&apiKey=" + apiKey;
        RestTemplate h = new RestTemplate();
		NewsResponse w = h.getForObject(URL, NewsResponse.class);
		return w;
    }

    @GetMapping("/sorted/{country}/{category}/{pno}/{size}")
    public List<Articles> getArticles(@PathVariable("country") String country, @PathVariable("category") String category,@PathVariable int pno, @PathVariable int size)
    {
        NewsResponse news = getWord(country, category);
        List<Articles> articles = news.getArticles();
        Collections.sort(articles,new Comparator<Articles>() {
            @Override
            public int compare(Articles a1, Articles a2) {
                return a1.getTitle().compareTo(a2.getTitle());
            }
        });
        List <Articles> articles1 = articles.subList((pno-1)*size, pno*size);

        return articles1;
    }
}
